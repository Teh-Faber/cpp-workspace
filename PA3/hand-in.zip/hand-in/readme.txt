OpenCV er downloaded med: sudo apt install libopencv-dev

Og er blevet linket til programmet med brug af cmake filen som er i denne mappe
